"""Train the mobile price model and save it.

    python train.py

It compares three models with 5-fold cross-validation, keeps the best one, tests it on
phones it has never seen, saves it to models/mobile_price_model.joblib and writes the
scores to models/metrics.json.
"""
import json
import sys

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_absolute_percentage_error, r2_score
from sklearn.model_selection import KFold, cross_val_score, train_test_split

import model_core as core

# Make ₹ and other symbols print correctly in Windows terminals
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")


def main() -> None:
    df = pd.read_csv(core.DATA_PATH)
    X = df[core.FEATURES]
    y = df[core.TARGET]
    print(f"Loaded {len(df):,} phones from {core.DATA_PATH.name}")

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=core.RANDOM_STATE)
    folds = KFold(n_splits=5, shuffle=True, random_state=core.RANDOM_STATE)

    results = {}
    for name in core.MODEL_NAMES:
        print(f"Training {core.MODEL_LABELS[name]} ...")
        cv = cross_val_score(core.make_pipeline(name), X_train, y_train, cv=folds, scoring="r2")
        model = core.make_pipeline(name).fit(X_train, y_train)
        pred = model.predict(X_test)
        results[name] = {
            "label": core.MODEL_LABELS[name],
            "cv_r2_mean": round(float(cv.mean()), 4),
            "cv_r2_std": round(float(cv.std()), 4),
            "test_r2": round(float(r2_score(y_test, pred)), 4),
            "test_mae_inr": round(float(mean_absolute_error(y_test, pred)), 0),
            "test_mape_pct": round(float(mean_absolute_percentage_error(y_test, pred) * 100), 2),
            "test_within_10pct": round(float(np.mean(np.abs(pred - y_test) / y_test <= 0.10) * 100), 1),
        }

    best = max(results, key=lambda k: results[k]["cv_r2_mean"])
    print(f"\nBest model (by cross-validation): {core.MODEL_LABELS[best]}")

    # Refit the best model on ALL the data for the saved version
    final = core.make_pipeline(best).fit(X, y)
    core.MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump({"model": final, "best_model": best, "features": core.FEATURES,
                 "brands": core.BRANDS}, core.MODEL_PATH)

    # Which specs matter most? Shuffle each spec on the test phones and see how much the score drops.
    from sklearn.inspection import permutation_importance
    fitted_best = core.make_pipeline(best).fit(X_train, y_train)
    perm = permutation_importance(fitted_best, X_test, y_test, n_repeats=5,
                                  random_state=core.RANDOM_STATE, scoring="r2")
    raw = np.clip(perm.importances_mean, 0, None)
    total = float(raw.sum()) or 1.0
    importance = sorted(
        [{"feature": f, "label": core.FEATURE_LABELS[f], "importance": round(float(v) / total * 100, 1)}
         for f, v in zip(core.FEATURES, raw)],
        key=lambda item: -item["importance"])

    summary = {"best_model": best, "rows": len(df), "models": results,
               "feature_importance": importance}
    core.METRICS_PATH.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print("\n{:28s} {:>10s} {:>10s} {:>12s} {:>9s} {:>12s}".format(
        "model", "CV R²", "test R²", "MAE (₹)", "MAPE %", "within 10%"))
    for name in core.MODEL_NAMES:
        r = results[name]
        print("{:28s} {:>10.4f} {:>10.4f} {:>12,.0f} {:>9.2f} {:>11.1f}%".format(
            r["label"], r["cv_r2_mean"], r["test_r2"], r["test_mae_inr"],
            r["test_mape_pct"], r["test_within_10pct"]))
    print(f"\nSaved model to {core.MODEL_PATH}")
    print(f"Scores saved to {core.METRICS_PATH}")


if __name__ == "__main__":
    main()
