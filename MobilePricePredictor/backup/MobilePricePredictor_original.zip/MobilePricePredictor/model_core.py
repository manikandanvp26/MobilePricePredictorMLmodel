"""Shared code: the features, the price categories, and the model pipelines.

Used by train.py (to build the model), predict.py (command line) and app.py (web page).
"""
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer, TransformedTargetRegressor
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "data" / "mobile_phones.csv"
MODEL_PATH = ROOT / "models" / "mobile_price_model.joblib"
METRICS_PATH = ROOT / "models" / "metrics.json"

TARGET = "price_inr"
CATEGORICAL = ["brand"]
NUMERIC = ["ram_gb", "storage_gb", "battery_mah", "main_camera_mp", "front_camera_mp",
           "screen_inch", "refresh_rate_hz", "processor_score", "has_5g", "fast_charging_w"]
FEATURES = CATEGORICAL + NUMERIC
BRANDS = ["Apple", "Samsung", "OnePlus", "Vivo", "Oppo", "Nothing", "Xiaomi", "Realme", "Motorola"]

RANDOM_STATE = 42


def price_category(price: float) -> str:
    """Friendly label for the predicted price (in INR)."""
    if price < 15000:
        return "Budget phone"
    if price < 30000:
        return "Entry-level phone"
    if price < 60000:
        return "Mid-range phone"
    if price < 100000:
        return "Premium phone"
    return "Flagship phone"


def make_pipeline(model_name: str) -> Pipeline:
    """Preprocessing + model in one object, so the same steps run at training and prediction time."""
    pre = ColumnTransformer([
        ("brand", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL),
        ("numbers", StandardScaler(), NUMERIC),
    ])
    if model_name == "ridge_regression":
        reg = Ridge(alpha=1.0)
    elif model_name == "random_forest":
        reg = RandomForestRegressor(n_estimators=200, min_samples_leaf=2, random_state=RANDOM_STATE)
    elif model_name == "gradient_boosting":
        reg = GradientBoostingRegressor(n_estimators=300, max_depth=3, learning_rate=0.05,
                                        subsample=0.9, random_state=RANDOM_STATE)
    else:
        raise ValueError(f"Unknown model: {model_name}")
    # Learn log(price): prices are skewed, and this keeps errors fair across cheap and costly phones
    model = TransformedTargetRegressor(regressor=Pipeline([("prep", pre), ("model", reg)]),
                                       func=np.log1p, inverse_func=np.expm1, check_inverse=False)
    return model


MODEL_NAMES = ["ridge_regression", "random_forest", "gradient_boosting"]
MODEL_LABELS = {
    "ridge_regression": "Linear (Ridge) Regression",
    "random_forest": "Random Forest",
    "gradient_boosting": "Gradient Boosting",
}


def phone_frame(values: dict) -> pd.DataFrame:
    """One phone's specs -> a one-row DataFrame in the training column layout."""
    row = {f: values[f] for f in FEATURES}
    return pd.DataFrame([row], columns=FEATURES)


# ---- Settings for the web pages (shared by app.py and the page) ----
FEATURE_LABELS = {
    "brand": "Brand", "ram_gb": "RAM (GB)", "storage_gb": "Storage (GB)",
    "battery_mah": "Battery (mAh)", "main_camera_mp": "Main camera (MP)",
    "front_camera_mp": "Front camera (MP)", "screen_inch": "Screen (inches)",
    "refresh_rate_hz": "Refresh rate (Hz)", "processor_score": "Processor score",
    "has_5g": "5G", "fast_charging_w": "Fast charging (W)",
}
# Choices for features that come in fixed steps
OPTIONS = {
    "ram_gb": [3, 4, 6, 8, 12, 16],
    "storage_gb": [32, 64, 128, 256, 512],
    "main_camera_mp": [12, 16, 32, 48, 50, 64, 108, 200],
    "front_camera_mp": [5, 8, 16, 32],
    "refresh_rate_hz": [60, 90, 120, 144],
    "fast_charging_w": [10, 18, 25, 33, 67, 120],
    "has_5g": [0, 1],
}
# Slider range for continuous features (the training data's range)
SLIDERS = {
    "battery_mah": (3000, 7000, 100),
    "screen_inch": (5.5, 6.9, 0.1),
    "processor_score": (40, 100, 1),
}
# Accepted range when a value is typed in (wider than the sliders)
VALID = {
    "ram_gb": (1, 32), "storage_gb": (8, 2048), "battery_mah": (1000, 12000),
    "main_camera_mp": (1, 300), "front_camera_mp": (1, 100), "screen_inch": (4, 9),
    "refresh_rate_hz": (30, 240), "processor_score": (1, 100), "has_5g": (0, 1),
    "fast_charging_w": (1, 300),
}
DEFAULTS = {
    "brand": "Samsung", "ram_gb": 8, "storage_gb": 128, "battery_mah": 5000,
    "main_camera_mp": 50, "front_camera_mp": 16, "screen_inch": 6.5,
    "refresh_rate_hz": 120, "processor_score": 70, "has_5g": 1, "fast_charging_w": 33,
}
MATCH_TOLERANCE_PCT = 8.0
