# Mobile Price Predictor

Predicts the price (in ₹) of a mobile phone from its specs: brand, RAM, storage, battery, cameras, screen, refresh rate, processor score, 5G and fast charging.

It trains three machine-learning models, keeps the best one, and gives you:
- a **web app** (`app.py`) with several interactive pages (lime and cherry red theme)
- a **command-line** tool (`predict.py`)

> **Note about the data:** the phone listings in `data/mobile_phones.csv` are **synthetic** (made up with a pricing rule in `data/generate_data.py`), because real listings were not available for this project. The accuracy you see reflects that rule. To use real prices, replace the CSV with real listings that have the same columns (or change the column names in `model_core.py`).

---

## Step 1: Open the project in VS Code

1. Open VS Code.
2. **File → Open Folder…** and choose the `MobilePricePredictor` folder.
3. Open the terminal: **Terminal → New Terminal** (or press `` Ctrl + ` ``).

You need **Python 3.10 or newer**. Check with:

```bash
python --version
```

(On some computers use `python3` instead of `python`.)

## Step 2: Create a virtual environment and install the packages

**Windows (PowerShell or the VS Code terminal):**
```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

If PowerShell says scripts are disabled, run this once and try the activate command again:
```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
```

**Mac / Linux:**
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

When it works, the terminal shows `(.venv)` at the start of the line.

In VS Code, pick this interpreter too: press `Ctrl+Shift+P` → **Python: Select Interpreter** → choose `.venv`.

## Step 3: Train the model

```bash
python train.py
```

This takes about a minute. It compares three models with 5-fold cross-validation, saves the best one to `models/mobile_price_model.joblib`, and writes the scores to `models/metrics.json`.

The data file is already included. To create it again, run `python data/generate_data.py`.

## Step 4: Open the web app

```bash
python app.py
```

Then open **http://127.0.0.1:5000** in your browser. Press `Ctrl+C` in the terminal to stop it. (If the model file is missing, the app trains it automatically the first time.)

The app has these pages, chosen from the left sidebar:

| Page | What you can do |
|---|---|
| **Predict Price** | Change any spec with sliders, pick boxes or typed values. The price updates instantly, with a typical range and a category. |
| **Compare Phones** | Add up to 4 phones and compare their prices side by side with bars and a table. |
| **Price Curve** | Pick one spec (for example RAM) and see how the price changes across its values. Hover for a value, click to use it on the Predict page. |
| **Batch Upload** | Upload a CSV or Excel file of phones and get a price for every row. Add a `price_inr` column to see whether each listed price is a close match, higher or lower than the estimate. Download the template to see the format, and download the results as CSV. |
| **Key Specs** | Shows which specs affect the price most for the active model. |
| **Model Evaluation** | Shows the scores of all three models (cross-validation R², test R², error in ₹, within 10%). |
| **About** | Explains how the app works and that the data is synthetic. |

## Step 5: Predict from the command line (optional)

**Option A: type the specs in the command**
```bash
python predict.py --brand Samsung --ram 8 --storage 256 --battery 5000 --camera 50 --5g 1 --charging 67
```

**Option B: answer the questions one by one**
```bash
python predict.py
```

Example output:
```
Predicted price: ₹60,304
Typical range:   ₹55,479 to ₹65,128
Category:        Premium phone
```

Use `python predict.py --help` to see all options.

---

## Run the tests

```bash
python -m unittest discover -s tests -v
```

There are 16 tests: 6 check the model's predictions and 10 check the web app's pages and API.

## Batch file format

The batch upload needs a `brand` column. Any other column left out uses a typical value. Column names:

`brand, ram_gb, storage_gb, battery_mah, main_camera_mp, front_camera_mp, screen_inch, refresh_rate_hz, processor_score, has_5g, fast_charging_w, price_inr`

`price_inr` is optional. Leave it out (or empty) to get predictions only.

## Project files

```
MobilePricePredictor/
├── app.py                  web app (Flask): pages and JSON API
├── predict.py              command-line prediction
├── train.py                trains and compares the models
├── model_core.py           features, price categories and model settings (shared)
├── requirements.txt        packages to install
├── data/
│   ├── generate_data.py    creates the synthetic phone listings
│   └── mobile_phones.csv   3,000 phone listings
├── models/
│   ├── mobile_price_model.joblib   the trained model (created by train.py)
│   └── metrics.json                scores and key specs (created by train.py)
├── static/
│   ├── style.css           lime and cherry red theme
│   ├── app.js              the interactive pages
│   └── phone_template.csv  template for batch upload
├── templates/
│   └── index.html          page layout
└── tests/
    ├── test_model.py       checks that the predictions make sense
    └── test_app.py         checks the web pages and API
```

## Web API

The web app also exposes these endpoints (useful for testing or other tools):

| Method | Address | Purpose |
|---|---|---|
| GET | `/api/schema` | options, slider ranges and defaults |
| POST | `/api/predict` | price for one phone |
| POST | `/api/compare` | prices for 1 to 4 phones |
| POST | `/api/curve` | price across the values of one spec |
| POST | `/api/batch` | prices for a CSV or Excel file (max 2,000 rows, 5 MB) |
| GET | `/api/metrics` | scores of all models |
| GET | `/api/insights` | key specs (feature importance) |
| GET | `/api/template` | download the batch template |

## Models compared

| Model | What it is |
|---|---|
| Linear (Ridge) Regression | simple straight-line model, a baseline |
| Random Forest | many decision trees voting together |
| Gradient Boosting | trees built one after another to fix earlier errors |

All three learn `log(price)`, because phone prices range from budget to flagship and the log keeps errors fair across that range. The best model is chosen by 5-fold cross-validation on the training phones.

## Troubleshooting

- **`ModuleNotFoundError`**: the virtual environment is not active. Run the activate command from Step 2, then `pip install -r requirements.txt` again.
- **`No trained model found`**: run `python train.py` first. (The web app also trains automatically if the model is missing.)
- **Port 5000 is busy**: change `port=5000` to `port=5001` at the bottom of `app.py`.
- **Batch upload says a column is missing**: the file needs a `brand` column. Download the template from the Batch Upload page.
