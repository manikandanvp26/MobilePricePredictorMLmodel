"""Predict a mobile phone's price from its specs (command line).

Examples:
    python predict.py --brand Samsung --ram 8 --storage 256 --battery 5000 --camera 50
    python predict.py            # asks you each question

Run  python train.py  first to create the model.
"""
import argparse
import sys

import joblib
import pandas as pd

import model_core as core

# Make ₹ and other symbols print correctly in Windows terminals
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")


def load_model():
    if not core.MODEL_PATH.exists():
        raise SystemExit("No trained model found. Run:  python train.py")
    return joblib.load(core.MODEL_PATH)


def predict_price(bundle: dict, specs: dict) -> float:
    """specs uses the feature names from model_core.FEATURES. Returns the price in INR."""
    frame = core.phone_frame(specs)
    price = float(bundle["model"].predict(frame)[0])
    return max(price, 0.0)


def ask_interactively() -> dict:
    print("Enter the phone's specs (press Enter to use the value in brackets):\n")

    def ask(text, default, cast=str):
        raw = input(f"{text} [{default}]: ").strip()
        return cast(raw) if raw else default

    brand = ask(f"Brand ({', '.join(core.BRANDS)})", "Samsung")
    return {
        "brand": brand,
        "ram_gb": ask("RAM (GB)", 8, int),
        "storage_gb": ask("Storage (GB)", 128, int),
        "battery_mah": ask("Battery (mAh)", 5000, int),
        "main_camera_mp": ask("Main camera (MP)", 50, int),
        "front_camera_mp": ask("Front camera (MP)", 16, int),
        "screen_inch": ask("Screen size (inches)", 6.5, float),
        "refresh_rate_hz": ask("Refresh rate (Hz)", 120, int),
        "processor_score": ask("Processor score (40-100)", 70, int),
        "has_5g": ask("5G? (1 = yes, 0 = no)", 1, int),
        "fast_charging_w": ask("Fast charging (W)", 33, int),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Predict a mobile phone price.")
    parser.add_argument("--brand", default="Samsung", choices=core.BRANDS)
    parser.add_argument("--ram", type=int, default=8, help="RAM in GB")
    parser.add_argument("--storage", type=int, default=128, help="Storage in GB")
    parser.add_argument("--battery", type=int, default=5000, help="Battery in mAh")
    parser.add_argument("--camera", type=int, default=50, help="Main camera in MP")
    parser.add_argument("--front-camera", type=int, default=16, help="Front camera in MP")
    parser.add_argument("--screen", type=float, default=6.5, help="Screen size in inches")
    parser.add_argument("--refresh", type=int, default=120, help="Refresh rate in Hz")
    parser.add_argument("--processor", type=int, default=70, help="Processor score (40-100)")
    parser.add_argument("--5g", dest="has_5g", type=int, default=1, help="1 = 5G, 0 = no 5G")
    parser.add_argument("--charging", type=int, default=33, help="Fast charging in watts")
    parser.add_argument("--interactive", action="store_true", help="Ask each question")
    args = parser.parse_args()

    if args.interactive or len(sys.argv) == 1:      # no arguments at all -> ask questions
        specs = ask_interactively()
    else:
        specs = {
            "brand": args.brand, "ram_gb": args.ram, "storage_gb": args.storage,
            "battery_mah": args.battery, "main_camera_mp": args.camera,
            "front_camera_mp": args.front_camera, "screen_inch": args.screen,
            "refresh_rate_hz": args.refresh, "processor_score": args.processor,
            "has_5g": args.has_5g, "fast_charging_w": args.charging,
        }

    bundle = load_model()
    price = predict_price(bundle, specs)
    low, high = price * 0.92, price * 1.08
    print(f"\nPredicted price: ₹{price:,.0f}")
    print(f"Typical range:   ₹{low:,.0f} to ₹{high:,.0f}")
    print(f"Category:        {core.price_category(price)}")


if __name__ == "__main__":
    main()
