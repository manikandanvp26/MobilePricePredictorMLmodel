"""Mobile Price Predictor – web app with several interactive pages.

Run:  python app.py      then open http://127.0.0.1:5000
"""
import io
import json

import joblib
import numpy as np
import pandas as pd
from flask import Flask, jsonify, render_template, request, send_from_directory
from werkzeug.exceptions import RequestEntityTooLarge

import model_core as core
from predict import predict_price

MAX_UPLOAD_MB = 5
MAX_BATCH_ROWS = 2000
MAX_COMPARE = 4

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_MB * 1024 * 1024
_state = {"bundle": None}


def get_bundle():
    if _state["bundle"] is None:
        if not core.MODEL_PATH.exists():
            import train
            train.main()
        _state["bundle"] = joblib.load(core.MODEL_PATH)
    return _state["bundle"]


def read_metrics() -> dict:
    return json.loads(core.METRICS_PATH.read_text(encoding="utf-8"))


def clean_specs(raw: dict) -> dict:
    """Check and convert the specs sent by the page. Raises ValueError with a friendly message."""
    specs = {}
    brand = raw.get("brand", core.DEFAULTS["brand"])
    if brand not in core.BRANDS:
        raise ValueError(f"Unknown brand '{brand}'. Choose one of: {', '.join(core.BRANDS)}.")
    specs["brand"] = brand
    for feature in core.FEATURES[1:]:
        value = raw.get(feature, core.DEFAULTS[feature])
        try:
            number = float(value)
        except (TypeError, ValueError):
            raise ValueError(f"{core.FEATURE_LABELS[feature]} must be a number.")
        low, high = core.VALID[feature]
        if not low <= number <= high:
            raise ValueError(f"{core.FEATURE_LABELS[feature]} must be between {low} and {high}.")
        specs[feature] = int(number) if float(number).is_integer() else round(number, 2)
    return specs


def price_payload(specs: dict) -> dict:
    price = predict_price(get_bundle(), specs)
    return {
        "specs": specs,
        "price": round(price, 0),
        "price_fmt": f"₹{price:,.0f}",
        "low_fmt": f"₹{price * 0.92:,.0f}",
        "high_fmt": f"₹{price * 1.08:,.0f}",
        "low": round(price * 0.92, 0),
        "high": round(price * 1.08, 0),
        "category": core.price_category(price),
    }


# ---------------- pages ----------------
@app.get("/")
def index():
    return render_template("index.html")


@app.get("/api/schema")
def schema():
    return jsonify({
        "brands": core.BRANDS,
        "labels": core.FEATURE_LABELS,
        "options": core.OPTIONS,
        "sliders": core.SLIDERS,
        "defaults": core.DEFAULTS,
        "model_name": core.MODEL_LABELS[get_bundle()["best_model"]],
    })


@app.post("/api/predict")
def api_predict():
    try:
        return jsonify(price_payload(clean_specs(request.get_json(silent=True) or {})))
    except ValueError as exc:
        return jsonify(error=str(exc)), 400


@app.post("/api/compare")
def api_compare():
    data = request.get_json(silent=True) or {}
    phones = data.get("phones", [])
    if not 1 <= len(phones) <= MAX_COMPARE:
        return jsonify(error=f"Compare between 1 and {MAX_COMPARE} phones."), 400
    try:
        results = [price_payload(clean_specs(p)) for p in phones]
    except ValueError as exc:
        return jsonify(error=str(exc)), 400
    return jsonify({"phones": results})


@app.post("/api/curve")
def api_curve():
    """Price for each value of one spec, with the other specs held at the given values."""
    data = request.get_json(silent=True) or {}
    feature = data.get("feature")
    if feature not in core.FEATURES:
        return jsonify(error="Choose a spec to plot."), 400
    try:
        base = clean_specs(data.get("specs", {}))
    except ValueError as exc:
        return jsonify(error=str(exc)), 400

    if feature == "brand":
        values = core.BRANDS
    elif feature in core.OPTIONS:
        values = core.OPTIONS[feature]
    else:
        low, high, step = core.SLIDERS[feature]
        values = list(np.round(np.linspace(low, high, 25), 2))

    points = []
    for v in values:
        specs = dict(base)
        specs[feature] = v
        price = predict_price(get_bundle(), specs)
        points.append({"x": v, "y": round(price, 0)})
    return jsonify({"feature": feature, "label": core.FEATURE_LABELS[feature], "points": points})


def read_upload(upload):
    data = upload.read()
    name = upload.filename.lower()
    if name.endswith((".xlsx", ".xls")):
        df = pd.read_excel(io.BytesIO(data))
    else:
        df = pd.read_csv(io.BytesIO(data), sep=None, engine="python")
    df.columns = [str(c).strip() for c in df.columns]
    return df.dropna(how="all").reset_index(drop=True)


def find_price_column(df):
    for name in ["price_inr", "price", "Price", "PRICE"]:
        if name in df.columns:
            return name
    return None


@app.post("/api/batch")
def api_batch():
    upload = request.files.get("file")
    if upload is None or not upload.filename:
        return jsonify(error="Choose a CSV or Excel file."), 400
    try:
        df = read_upload(upload)
    except Exception as exc:
        return jsonify(error=f"Could not read the file: {exc}"), 400
    if df.empty:
        return jsonify(error="The file has no rows."), 400
    if len(df) > MAX_BATCH_ROWS:
        return jsonify(error=f"Maximum {MAX_BATCH_ROWS} rows per file."), 400
    if "brand" not in df.columns:
        return jsonify(error="The file needs a 'brand' column. Download the template to see the format."), 400

    defaults = core.DEFAULTS
    missing = [f for f in core.FEATURES if f not in df.columns]
    price_col = find_price_column(df)
    actual = pd.to_numeric(df[price_col], errors="coerce") if price_col else None
    if actual is not None and actual.notna().sum() == 0:
        actual = None                                   # an empty price column counts as no prices

    rows, counts = [], {"Close Match": 0, "Higher": 0, "Lower": 0, "Predicted": 0}
    for i, rec in df.iterrows():
        raw = {f: (rec[f] if f in df.columns else defaults[f]) for f in core.FEATURES}
        try:
            specs = clean_specs(raw)
        except ValueError as exc:
            rows.append({"row": int(i) + 1, "error": str(exc)})
            continue
        price = predict_price(get_bundle(), specs)
        a = None if actual is None or pd.isna(actual.iloc[i]) or actual.iloc[i] <= 0 else float(actual.iloc[i])
        status, pct = "Predicted", None
        if a is not None:
            pct = round((price - a) / a * 100, 1)
            if abs(pct) <= core.MATCH_TOLERANCE_PCT:
                status = "Close Match"
            elif a > price:
                status = "Higher"
            else:
                status = "Lower"
        counts[status] += 1
        rows.append({
            "row": int(i) + 1, "brand": specs["brand"], "ram_gb": specs["ram_gb"],
            "storage_gb": specs["storage_gb"], "processor_score": specs["processor_score"],
            "predicted": round(price, 0), "predicted_fmt": f"₹{price:,.0f}",
            "actual": None if a is None else round(a, 0),
            "actual_fmt": None if a is None else f"₹{a:,.0f}",
            "diff_pct": pct, "status": status,
        })
    return jsonify({
        "total": len(rows), "has_actual": actual is not None, "missing": missing,
        "counts": counts, "rows": rows[:MAX_BATCH_ROWS],
    })


@app.get("/api/metrics")
def api_metrics():
    data = read_metrics()
    data["labels"] = {k: v["label"] for k, v in data["models"].items()}
    return jsonify(data)


@app.get("/api/insights")
def api_insights():
    return jsonify(read_metrics().get("feature_importance", []))


@app.get("/api/template")
def template():
    return send_from_directory(core.ROOT / "static", "phone_template.csv", as_attachment=True)


@app.errorhandler(RequestEntityTooLarge)
def too_large(_exc):
    return jsonify(error=f"This file is larger than {MAX_UPLOAD_MB} MB."), 413


if __name__ == "__main__":
    app.run(debug=True, port=5000)
