"""Creates data/mobile_phones.csv: 3,000 synthetic mobile phone listings with prices in INR.

Run from the project folder:  python data/generate_data.py
(The CSV is already included, so running this is optional.)

The prices follow a made-up but realistic rule (more RAM, storage, camera, faster chip,
5G and fast charging cost more; some brands cost more). Random noise is added so the
model has to learn the pattern rather than memorise it.
"""
from pathlib import Path

import numpy as np
import pandas as pd

SEED = 42
N_PHONES = 3000
OUT = Path(__file__).resolve().parent / "mobile_phones.csv"

# Brand price multiplier: how much more (or less) the brand name costs
BRAND_FACTOR = {
    "Apple": 1.60, "Samsung": 1.15, "OnePlus": 1.05, "Vivo": 0.95, "Oppo": 0.90,
    "Nothing": 0.90, "Xiaomi": 0.85, "Realme": 0.80, "Motorola": 0.75,
}


def main() -> None:
    rng = np.random.default_rng(SEED)
    n = N_PHONES

    brand = rng.choice(list(BRAND_FACTOR), n)
    ram_gb = rng.choice([3, 4, 6, 8, 12, 16], n, p=[.10, .15, .20, .25, .20, .10])
    storage_gb = rng.choice([32, 64, 128, 256, 512], n, p=[.10, .20, .35, .25, .10])
    battery_mah = rng.integers(3000, 7001, n)
    main_camera_mp = rng.choice([12, 16, 32, 48, 50, 64, 108, 200], n)
    front_camera_mp = rng.choice([5, 8, 16, 32], n)
    screen_inch = np.round(rng.uniform(5.5, 6.9, n), 1)
    refresh_rate_hz = rng.choice([60, 90, 120, 144], n, p=[.35, .25, .30, .10])
    processor_score = rng.integers(40, 100, n)       # benchmark-style score (higher = faster)
    has_5g = rng.integers(0, 2, n)
    fast_charging_w = rng.choice([10, 18, 25, 33, 67, 120], n)

    base = (3000
            + ram_gb * 1200
            + storage_gb * 35
            + battery_mah * 0.9
            + main_camera_mp * 60
            + front_camera_mp * 40
            + processor_score * 180
            + refresh_rate_hz * 25
            + fast_charging_w * 70
            + has_5g * 2500)
    factor = np.array([BRAND_FACTOR[b] for b in brand])
    noise = rng.lognormal(mean=0.0, sigma=0.08, size=n)
    price = base * factor * noise
    price = np.floor(price / 100) * 100 + 99          # Indian-style prices ending in 99

    df = pd.DataFrame({
        "brand": brand,
        "ram_gb": ram_gb,
        "storage_gb": storage_gb,
        "battery_mah": battery_mah,
        "main_camera_mp": main_camera_mp,
        "front_camera_mp": front_camera_mp,
        "screen_inch": screen_inch,
        "refresh_rate_hz": refresh_rate_hz,
        "processor_score": processor_score,
        "has_5g": has_5g,
        "fast_charging_w": fast_charging_w,
        "price_inr": price.astype(int),
    })
    df.to_csv(OUT, index=False)
    print(f"Saved {len(df)} phones to {OUT}")
    print(f"Price range: ₹{df.price_inr.min():,} to ₹{df.price_inr.max():,}")


if __name__ == "__main__":
    main()
