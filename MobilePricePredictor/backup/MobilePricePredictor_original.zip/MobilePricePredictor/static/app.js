(() => {
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => document.querySelectorAll(s);
  const MAX_COMPARE = 4;
  const PRICE_SCALE = 150000;             // right-hand edge of the range bar (₹)
  const UNITS = { ram_gb: "GB", storage_gb: "GB", main_camera_mp: "MP", front_camera_mp: "MP",
                  refresh_rate_hz: "Hz", fast_charging_w: "W", battery_mah: "mAh", screen_inch: "in" };

  const state = { S: null, specs: null, compare: [], lastBatch: null };

  // ---------- helpers ----------
  const inr = (n) => "₹" + Math.round(n).toLocaleString("en-IN");
  const esc = (s) => String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const debounce = (fn, ms = 250) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

  function el(tag, attrs = {}, text) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) node.setAttribute(k, v);
    if (text !== undefined && text !== null) node.textContent = text;
    return node;
  }
  function toast(msg, isError = false) {
    const t = $("#toast");
    t.textContent = msg;
    t.classList.toggle("is-error", isError);
    t.hidden = false;
    clearTimeout(toast._t);
    toast._t = setTimeout(() => { t.hidden = true; }, 3200);
  }
  async function api(url, options) {
    const res = await fetch(url, options);
    let data;
    try { data = await res.json(); } catch { data = { error: "Unexpected server response" }; }
    if (!res.ok || data.error) throw new Error(data.error || "Request failed");
    return data;
  }
  const postJSON = (url, body) => api(url, {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
  });
  function labelOf(feature, value) {
    if (feature === "has_5g") return value === 1 ? "Yes" : "No";
    if (feature === "brand") return value;
    const unit = UNITS[feature];
    return unit ? `${value} ${unit}` : String(value);
  }

  // ---------- navigation ----------
  function showView(name) {
    $$(".view").forEach((v) => v.classList.toggle("is-visible", v.dataset.view === name));
    $$(".nav-item").forEach((b) => b.classList.toggle("is-active", b.dataset.nav === name));
    if (name === "compare") updateCompare();
    if (name === "curve") drawCurve();
    if (name === "insights") loadInsights();
    if (name === "eval") loadEval();
  }
  $$(".nav-item").forEach((b) => b.addEventListener("click", () => showView(b.dataset.nav)));

  // ---------- controls (used by Predict and Compare) ----------
  function makeControl(feature, value, onChange) {
    const wrap = el("label", { class: "control" });
    const title = el("span", {}, state.S.labels[feature]);
    wrap.appendChild(title);

    if (state.S.sliders[feature]) {
      const [min, max, step] = state.S.sliders[feature];
      const input = el("input", { type: "range", min, max, step });
      input.value = value;
      const out = el("span", { class: "val" }, labelOf(feature, Number(value)));
      title.appendChild(out);
      input.addEventListener("input", () => {
        out.textContent = labelOf(feature, Number(input.value));
        onChange(feature, Number(input.value));
      });
      wrap.appendChild(input);
      return wrap;
    }

    const select = el("select");
    const options = feature === "brand" ? state.S.brands : (state.S.options[feature] || []);
    options.forEach((v) => {
      const opt = el("option", { value: String(v) }, labelOf(feature, v));
      if (String(v) === String(value)) opt.selected = true;
      select.appendChild(opt);
    });
    select.addEventListener("change", () => {
      onChange(feature, feature === "brand" ? select.value : Number(select.value));
    });
    wrap.appendChild(select);
    return wrap;
  }
  function buildControls(container, specs, onChange) {
    container.innerHTML = "";
    Object.keys(state.S.labels).forEach((f) => container.appendChild(makeControl(f, specs[f], onChange)));
  }

  // ---------- Predict page ----------
  const runPredict = debounce(async () => {
    try {
      const r = await postJSON("/api/predict", state.specs);
      $("#predictError").textContent = "";
      $("#priceOut").textContent = r.price_fmt;
      $("#rangeText").textContent = `Typical range: ${r.low_fmt} to ${r.high_fmt}`;
      $("#catOut").textContent = r.category;
      const fill = $("#rangeFill");
      fill.style.left = `${Math.min(100, (r.low / PRICE_SCALE) * 100)}%`;
      fill.style.width = `${Math.min(100 - (r.low / PRICE_SCALE) * 100, ((r.high - r.low) / PRICE_SCALE) * 100)}%`;
    } catch (err) {
      $("#predictError").textContent = err.message;
    }
  }, 220);

  function onPredictChange(feature, value) {
    state.specs[feature] = value;
    runPredict();
  }

  $("#addToCompare").addEventListener("click", () => {
    if (state.compare.length >= MAX_COMPARE) return toast(`You can compare up to ${MAX_COMPARE} phones.`, true);
    state.compare.push({ ...state.specs });
    toast("Added to Compare");
  });

  // ---------- Compare page ----------
  const updateCompare = debounce(async () => {
    try {
      const r = await postJSON("/api/compare", { phones: state.compare });
      const max = Math.max(...r.phones.map((p) => p.price), 1);
      $("#compareBars").innerHTML = "";
      r.phones.forEach((p, i) => {
        const s = p.specs;
        const row = el("div", { class: "bar-row" });
        row.appendChild(el("div", { class: "name" }, `${i + 1}. ${s.brand}`));
        const track = el("div", { class: "bar-track" });
        track.appendChild(el("div", { class: "bar-fill", style: `width:${(p.price / max) * 100}%` }));
        row.appendChild(track);
        row.appendChild(el("div", { class: "bar-val" }, p.price_fmt));
        $("#compareBars").appendChild(row);
      });
      const table = $("#compareTable");
      table.innerHTML = "<tr><th>Phone</th><th>Brand</th><th class='num'>RAM</th><th class='num'>Storage</th><th class='num'>Camera</th><th class='num'>Processor</th><th class='num'>Price</th><th>Range</th><th>Category</th></tr>";
      r.phones.forEach((p, i) => {
        const s = p.specs;
        table.appendChild(el("tr", {}, "")).innerHTML =
          `<td>${i + 1}</td><td>${esc(s.brand)}</td><td class="num">${s.ram_gb} GB</td>` +
          `<td class="num">${s.storage_gb} GB</td><td class="num">${s.main_camera_mp} MP</td>` +
          `<td class="num">${s.processor_score}</td><td class="num"><b>${p.price_fmt}</b></td>` +
          `<td>${p.low_fmt} – ${p.high_fmt}</td><td>${esc(p.category)}</td>`;
      });
    } catch (err) {
      toast(err.message, true);
    }
  }, 220);

  function renderPhoneCards() {
    const grid = $("#phoneGrid");
    grid.innerHTML = "";
    state.compare.forEach((specs, i) => {
      const card = el("div", { class: "card phone-card" });
      card.appendChild(el("h2", {}, `Phone ${i + 1}`));
      if (state.compare.length > 1) {
        const rm = el("button", { class: "btn ghost remove" }, "✕");
        rm.addEventListener("click", () => { state.compare.splice(i, 1); renderPhoneCards(); updateCompare(); });
        card.appendChild(rm);
      }
      const controls = el("div", { class: "controls" });
      Object.keys(state.S.labels).forEach((f) => {
        controls.appendChild(makeControl(f, specs[f], (feat, v) => { specs[feat] = v; updateCompare(); }));
      });
      card.appendChild(controls);
      grid.appendChild(card);
    });
    $("#addPhone").disabled = state.compare.length >= MAX_COMPARE;
  }
  $("#addPhone").addEventListener("click", () => {
    if (state.compare.length >= MAX_COMPARE) return toast(`You can compare up to ${MAX_COMPARE} phones.`, true);
    state.compare.push({ ...state.compare[state.compare.length - 1] });
    renderPhoneCards();
    updateCompare();
  });

  // ---------- Price curve ----------
  function populateCurveSelect() {
    const sel = $("#curveFeature");
    sel.innerHTML = "";
    Object.entries(state.S.labels).forEach(([k, label]) => sel.appendChild(el("option", { value: k }, label)));
    sel.value = "ram_gb";
    sel.addEventListener("change", drawCurve);
  }

  async function drawCurve() {
    const feature = $("#curveFeature").value;
    $("#curveTitle").textContent = `How the price changes with ${state.S.labels[feature]}`;
    let data;
    try {
      data = await postJSON("/api/curve", { feature, specs: state.specs });
    } catch (err) {
      return toast(err.message, true);
    }
    const svg = $("#chart");
    const W = 720, H = 340, padL = 80, padR = 20, padT = 20, padB = 56;
    const pts = data.points;
    const ys = pts.map((p) => p.y);
    const yMin = Math.max(0, Math.min(...ys) * 0.9), yMax = Math.max(...ys) * 1.08;
    const x = (i) => padL + (pts.length === 1 ? 0 : (i * (W - padL - padR)) / (pts.length - 1));
    const y = (v) => H - padB - ((v - yMin) / (yMax - yMin || 1)) * (H - padT - padB);
    const NS = "http://www.w3.org/2000/svg";
    const mk = (tag, attrs, text) => {
      const n = document.createElementNS(NS, tag);
      Object.entries(attrs).forEach(([k, v]) => n.setAttribute(k, v));
      if (text !== undefined) n.textContent = text;
      return n;
    };
    svg.innerHTML = "";

    // grid lines and price labels
    for (let t = 0; t <= 4; t++) {
      const v = yMin + ((yMax - yMin) * t) / 4;
      svg.appendChild(mk("line", { x1: padL, x2: W - padR, y1: y(v), y2: y(v), stroke: "var(--line)" }));
      svg.appendChild(mk("text", { x: padL - 8, y: y(v) + 4, "text-anchor": "end", "font-size": 12, fill: "var(--muted)" },
        `₹${Math.round(v / 1000)}k`));
    }
    // line
    svg.appendChild(mk("polyline", {
      points: pts.map((p, i) => `${x(i)},${y(p.y)}`).join(" "),
      fill: "none", stroke: "var(--cherry)", "stroke-width": 3, "stroke-linejoin": "round",
    }));
    // x labels (thinned out when there are many)
    const step = Math.ceil(pts.length / 8);
    pts.forEach((p, i) => {
      if (i % step === 0 || i === pts.length - 1) {
        svg.appendChild(mk("text", { x: x(i), y: H - padB + 20, "text-anchor": "middle", "font-size": 12, fill: "var(--muted)" },
          labelOf(feature, p.x)));
      }
    });
    // points: dots plus big transparent hit areas for hover and click
    const tip = $("#tooltip");
    pts.forEach((p, i) => {
      svg.appendChild(mk("circle", { cx: x(i), cy: y(p.y), r: 4, fill: "var(--lime-deep)" }));
      const hit = mk("circle", { cx: x(i), cy: y(p.y), r: 16, fill: "transparent", style: "cursor:pointer" });
      hit.addEventListener("mouseenter", () => {
        const box = $("#chartBox").getBoundingClientRect();
        const svgBox = svg.getBoundingClientRect();
        tip.hidden = false;
        tip.textContent = `${labelOf(feature, p.x)} → ${inr(p.y)}`;
        tip.style.left = `${svgBox.left - box.left + (x(i) / W) * svgBox.width}px`;
        tip.style.top = `${svgBox.top - box.top + (y(p.y) / H) * svgBox.height}px`;
      });
      hit.addEventListener("mouseleave", () => { tip.hidden = true; });
      hit.addEventListener("click", () => {
        state.specs[feature] = p.x;
        buildControls($("#predictControls"), state.specs, onPredictChange);
        runPredict();
        toast(`Set ${state.S.labels[feature]} to ${labelOf(feature, p.x)} on Predict`);
      });
      svg.appendChild(hit);
    });
  }

  // ---------- Batch upload ----------
  const drop = $("#dropzone");
  const fileInput = $("#fileInput");
  $("#browseBtn").addEventListener("click", () => fileInput.click());
  drop.addEventListener("click", (e) => { if (e.target === drop) fileInput.click(); });
  drop.addEventListener("dragover", (e) => { e.preventDefault(); drop.classList.add("is-drag"); });
  drop.addEventListener("dragleave", () => drop.classList.remove("is-drag"));
  drop.addEventListener("drop", (e) => {
    e.preventDefault();
    drop.classList.remove("is-drag");
    if (e.dataTransfer.files[0]) uploadBatch(e.dataTransfer.files[0]);
  });
  fileInput.addEventListener("change", () => {
    if (fileInput.files[0]) uploadBatch(fileInput.files[0]);
    fileInput.value = "";
  });

  async function uploadBatch(file) {
    toast("Pricing your phones…");
    const body = new FormData();
    body.append("file", file);
    try {
      const data = await api("/api/batch", { method: "POST", body });
      state.lastBatch = data;
      renderBatch(data);
      $("#downloadBatch").disabled = false;
      toast(`Priced ${data.total} phones`);
    } catch (err) {
      toast(err.message, true);
    }
  }

  function renderBatch(d) {
    $("#batchResults").hidden = false;
    const c = d.counts;
    $("#batchStats").innerHTML = [
      [d.total, "Phones"], [c["Close Match"], "Close match"], [c["Higher"], "Listed above estimate"],
      [c["Lower"], "Good deal"], [c["Predicted"], "No price given"],
    ].map(([v, l]) => `<div class="stat"><div class="stat-value">${v}</div><div class="stat-label">${l}</div></div>`).join("");
    if (d.missing && d.missing.length) {
      $("#batchStats").appendChild(el("div", { class: "hint", style: "grid-column:1/-1" },
        `Columns not in the file, filled with typical values: ${d.missing.map((m) => state.S.labels[m] || m).join(", ")}.`));
    }
    const pillFor = (s) => s === "Close Match" ? "ok" : s === "Higher" ? "high" : s === "Lower" ? "low" : "none";
    const table = $("#batchTable");
    table.innerHTML = "<tr><th>Row</th><th>Brand</th><th class='num'>RAM</th><th class='num'>Storage</th><th class='num'>Processor</th><th class='num'>Predicted</th><th class='num'>Actual</th><th class='num'>Diff %</th><th>Status</th></tr>";
    d.rows.forEach((r) => {
      if (r.error) {
        table.appendChild(el("tr", {}, "")).innerHTML = `<td>${r.row}</td><td colspan="8" style="color:var(--cherry-deep)">${esc(r.error)}</td>`;
        return;
      }
      table.appendChild(el("tr", {}, "")).innerHTML =
        `<td>${r.row}</td><td>${esc(r.brand)}</td><td class="num">${r.ram_gb} GB</td>` +
        `<td class="num">${r.storage_gb} GB</td><td class="num">${r.processor_score}</td>` +
        `<td class="num"><b>${r.predicted_fmt}</b></td><td class="num">${r.actual_fmt ?? "—"}</td>` +
        `<td class="num">${r.diff_pct === null ? "—" : (r.diff_pct > 0 ? "+" : "") + r.diff_pct + "%"}</td>` +
        `<td><span class="pill ${pillFor(r.status)}">${esc(r.status === "Lower" ? "Lower / Good deal" : r.status)}</span></td>`;
    });
  }

  $("#downloadBatch").addEventListener("click", () => {
    const rows = state.lastBatch ? state.lastBatch.rows.filter((r) => !r.error) : [];
    if (!rows.length) return;
    const headers = ["row", "brand", "ram_gb", "storage_gb", "processor_score", "predicted_price", "actual_price", "diff_pct", "status"];
    const lines = rows.map((r) => [r.row, r.brand, r.ram_gb, r.storage_gb, r.processor_score,
      r.predicted, r.actual ?? "", r.diff_pct ?? "", r.status]
      .map((v) => `"${String(v).replace(/"/g, '""')}"`).join(","));
    const blob = new Blob([[headers.join(","), ...lines].join("\n")], { type: "text/csv" });
    const a = el("a", { href: URL.createObjectURL(blob), download: "phone_price_predictions.csv" });
    document.body.appendChild(a);
    a.click();
    a.remove();
  });

  // ---------- Key specs (insights) ----------
  async function loadInsights() {
    const list = $("#importanceList");
    if (list.childElementCount) return;
    try {
      const items = await api("/api/insights");
      const max = Math.max(...items.map((i) => i.importance), 1);
      items.forEach((i) => {
        const row = el("div", { class: "imp-row" });
        row.appendChild(el("div", { class: "name" }, i.label));
        const track = el("div", { class: "bar-track" });
        track.appendChild(el("div", { class: "bar-fill", style: `width:${(i.importance / max) * 100}%` }));
        row.appendChild(track);
        row.appendChild(el("div", { class: "pct" }, `${i.importance}%`));
        list.appendChild(row);
      });
    } catch (err) {
      list.appendChild(el("p", { class: "muted" }, err.message));
    }
  }

  // ---------- Model evaluation ----------
  async function loadEval() {
    if ($("#evalTable").childElementCount) return;
    try {
      const m = await api("/api/metrics");
      const cards = $("#modelCards");
      cards.innerHTML = "";
      Object.entries(m.models).forEach(([key, r]) => {
        const card = el("div", { class: `model-card ${key === m.best_model ? "is-best" : ""}` });
        card.appendChild(el("h3", {}, r.label));
        card.appendChild(el("div", { class: "big" }, `${(r.cv_r2_mean * 100).toFixed(1)}%`));
        card.appendChild(el("div", { class: "muted" }, "Cross-validated R² (5-fold)"));
        card.appendChild(el("div", { class: "muted" }, `Within ±10%: ${r.test_within_10pct}%  ·  MAE ₹${Math.round(r.test_mae_inr).toLocaleString("en-IN")}`));
        if (key === m.best_model) card.appendChild(el("span", { class: "badge" }, "Active model"));
        cards.appendChild(card);
      });
      const t = $("#evalTable");
      t.innerHTML = "<tr><th>Model</th><th class='num'>CV R²</th><th class='num'>± std</th><th class='num'>Test R²</th><th class='num'>MAE (₹)</th><th class='num'>MAPE</th><th class='num'>Within ±10%</th></tr>";
      Object.values(m.models).forEach((r) => {
        t.appendChild(el("tr", {}, "")).innerHTML =
          `<td>${esc(r.label)}</td><td class="num">${r.cv_r2_mean.toFixed(4)}</td><td class="num">${r.cv_r2_std.toFixed(4)}</td>` +
          `<td class="num">${r.test_r2.toFixed(4)}</td><td class="num">${Math.round(r.test_mae_inr).toLocaleString("en-IN")}</td>` +
          `<td class="num">${r.test_mape_pct.toFixed(2)}%</td><td class="num">${r.test_within_10pct}%</td>`;
      });
      $("#evalNote").textContent = "Dataset: " + m.rows.toLocaleString("en-IN") + " synthetic phone listings. Cross-validation averages 5 different train/test splits.";
    } catch (err) {
      toast(err.message, true);
    }
  }

  // ---------- start ----------
  async function init() {
    try {
      state.S = await api("/api/schema");
    } catch (err) {
      toast("Could not load the app: " + err.message, true);
      return;
    }
    state.specs = { ...state.S.defaults };
    state.compare = [{ ...state.S.defaults }, { ...state.S.defaults, brand: "Apple", processor_score: 90, ram_gb: 8 }];
    $("#modelChip").textContent = `Active model: ${state.S.model_name}`;
    $("#predictModel").textContent = `Model: ${state.S.model_name}`;
    $("#sidebarFoot").textContent = `Model: ${state.S.model_name}`;
    buildControls($("#predictControls"), state.specs, onPredictChange);
    populateCurveSelect();
    renderPhoneCards();
    runPredict();
  }
  init();
})();
