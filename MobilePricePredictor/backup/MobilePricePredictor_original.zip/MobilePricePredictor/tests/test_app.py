"""Tests for the web API (the pages' data).

Run from the project folder:  python -m unittest discover -s tests -v
"""
import io
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import app as webapp  # noqa: E402
import model_core as core  # noqa: E402


class AppTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = webapp.app.test_client()

    def test_home_page_loads(self):
        r = self.client.get("/")
        self.assertEqual(r.status_code, 200)
        self.assertIn(b"Price Curve", r.data)

    def test_schema_lists_brands_and_model(self):
        data = self.client.get("/api/schema").get_json()
        self.assertIn("Apple", data["brands"])
        self.assertIn("model_name", data)

    def test_predict_returns_price_and_range(self):
        r = self.client.post("/api/predict", json=core.DEFAULTS)
        data = r.get_json()
        self.assertEqual(r.status_code, 200)
        self.assertGreater(data["price"], 0)
        self.assertLess(data["low"], data["price"])
        self.assertGreater(data["high"], data["price"])

    def test_predict_rejects_bad_values(self):
        r = self.client.post("/api/predict", json={**core.DEFAULTS, "ram_gb": "lots"})
        self.assertEqual(r.status_code, 400)
        self.assertIn("RAM", r.get_json()["error"])
        r = self.client.post("/api/predict", json={**core.DEFAULTS, "brand": "Nokia"})
        self.assertEqual(r.status_code, 400)

    def test_compare_limits_and_results(self):
        phones = [core.DEFAULTS, {**core.DEFAULTS, "brand": "Apple"}]
        data = self.client.post("/api/compare", json={"phones": phones}).get_json()
        self.assertEqual(len(data["phones"]), 2)
        too_many = self.client.post("/api/compare", json={"phones": [core.DEFAULTS] * 5})
        self.assertEqual(too_many.status_code, 400)

    def test_curve_covers_every_option(self):
        data = self.client.post("/api/curve", json={"feature": "ram_gb", "specs": core.DEFAULTS}).get_json()
        self.assertEqual([p["x"] for p in data["points"]], core.OPTIONS["ram_gb"])
        prices = [p["y"] for p in data["points"]]
        self.assertEqual(prices, sorted(prices))            # more RAM -> not cheaper

    def test_batch_accepts_the_template(self):
        template = Path(core.ROOT / "static" / "phone_template.csv").read_bytes()
        r = self.client.post("/api/batch", data={"file": (io.BytesIO(template), "phones.csv")},
                             content_type="multipart/form-data")
        data = r.get_json()
        self.assertEqual(r.status_code, 200)
        self.assertEqual(data["total"], 3)
        self.assertTrue(data["has_actual"] is False)         # template has empty price cells

    def test_batch_compares_with_actual_prices(self):
        csv = b"brand,ram_gb,storage_gb,price_inr\nSamsung,8,128,30000\nApple,8,128,1000\n"
        data = self.client.post("/api/batch", data={"file": (io.BytesIO(csv), "p.csv")},
                                content_type="multipart/form-data").get_json()
        self.assertTrue(data["has_actual"])
        statuses = {r["status"] for r in data["rows"]}
        self.assertIn("Lower", statuses)                    # listed far below the estimate for Apple
        self.assertEqual(sum(data["counts"].values()), 2)

    def test_batch_needs_brand_column(self):
        r = self.client.post("/api/batch", data={"file": (io.BytesIO(b"ram_gb\n8\n"), "x.csv")},
                             content_type="multipart/form-data")
        self.assertEqual(r.status_code, 400)

    def test_metrics_and_insights(self):
        metrics = self.client.get("/api/metrics").get_json()
        self.assertIn("models", metrics)
        insights = self.client.get("/api/insights").get_json()
        self.assertTrue(insights and "label" in insights[0])


if __name__ == "__main__":
    unittest.main()
