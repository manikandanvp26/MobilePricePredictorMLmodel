"""Quick checks that the model behaves sensibly.

Run from the project folder:  python -m unittest discover -s tests -v
"""
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import joblib  # noqa: E402

import model_core as core  # noqa: E402
import train  # noqa: E402
from predict import predict_price  # noqa: E402


def base_specs(**changes):
    specs = {
        "brand": "Samsung", "ram_gb": 8, "storage_gb": 128, "battery_mah": 5000,
        "main_camera_mp": 50, "front_camera_mp": 16, "screen_inch": 6.5,
        "refresh_rate_hz": 120, "processor_score": 70, "has_5g": 1, "fast_charging_w": 33,
    }
    specs.update(changes)
    return specs


class ModelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not core.MODEL_PATH.exists():
            train.main()
        cls.bundle = joblib.load(core.MODEL_PATH)

    def test_prediction_is_a_positive_number(self):
        price = predict_price(self.bundle, base_specs())
        self.assertGreater(price, 0)

    def test_more_ram_costs_more(self):
        low = predict_price(self.bundle, base_specs(ram_gb=4))
        high = predict_price(self.bundle, base_specs(ram_gb=16))
        self.assertGreater(high, low)

    def test_apple_costs_more_than_realme_for_same_specs(self):
        apple = predict_price(self.bundle, base_specs(brand="Apple"))
        realme = predict_price(self.bundle, base_specs(brand="Realme"))
        self.assertGreater(apple, realme)

    def test_faster_processor_costs_more(self):
        slow = predict_price(self.bundle, base_specs(processor_score=45))
        fast = predict_price(self.bundle, base_specs(processor_score=95))
        self.assertGreater(fast, slow)

    def test_price_categories(self):
        self.assertEqual(core.price_category(12000), "Budget phone")
        self.assertEqual(core.price_category(45000), "Mid-range phone")
        self.assertEqual(core.price_category(150000), "Flagship phone")

    def test_saved_metrics_are_reasonable(self):
        import json
        metrics = json.loads(core.METRICS_PATH.read_text(encoding="utf-8"))
        best = metrics["models"][metrics["best_model"]]
        self.assertGreater(best["cv_r2_mean"], 0.8)


if __name__ == "__main__":
    unittest.main()
